#include <stdio.h>           // Inclusione della libreria standard per input/output
#include <math.h>            // Inclusione della libreria matematica per sqrt()

int main() {                 // Funzione principale del programma
    
	double n1, n2, n3;       // Variabili per i 3 numeri inseriti dall'utente
    double media_dec;        // Media aritmetica con decimali
    int media_arr;           // Media aritmetica arrotondata (intero)
    double a_q_dec, a_q_arr; // Aree del quadrato (decimale e arrotondata)
    double a_c_dec, a_c_arr; // Aree del cerchio (decimale e arrotondata)
    double a_t_dec, a_t_arr; // Aree del triangolo (decimale e arrotondata)
    double PI = 3.14;        // Definizione della costante PI
	char scelta;             // Variabile per memorizzare la scelta di continuare o uscire
	
	do {                     // Inizio del ciclo del programma che consente di proseguire o terminare
  		  	
			// Richiesta dei 3 numeri all'utente
    		printf("Inserisci il primo numero: ");  
    		scanf("%lf", &n1);       // Lettura del primo numero
    		printf("Inserisci il secondo numero: ");  
    		scanf("%lf", &n2);       // Lettura del secondo numero
    		printf("Inserisci il terzo numero: ");  
    		scanf("%lf", &n3);       // Lettura del terzo numero

    		// Calcolo della media aritmetica con decimali
    		media_dec = (n1 + n2 + n3) / 3; 
	 
    		// Calcolo della media arrotondata 
    		media_arr = (int)(media_dec + 0.5);   // Aggiunge 0.5 per arrotondare correttamente

    		// Stampa delle medie
    		printf("\nMedia con 2 decimali: %.2lf\n", media_dec);  
    		printf("Media arrotondata: %d\n", media_arr);  

    		// Calcolo aree del quadrato
    		a_q_dec = media_dec * media_dec;            // Area con media decimale
    		a_q_arr = media_arr * media_arr;            // Area con media arrotondata
    		printf("\nArea quadrato (decimale): %.2lf\n", a_q_dec);  
    		printf("Area quadrato (arrotondata): %.2lf\n", a_q_arr);  

    		// Calcolo aree del cerchio (raggio = D/2)
    		a_c_dec = PI * (media_dec / 2) * (media_dec / 2);  // Area con media decimale
    		a_c_arr = PI * (media_arr / 2) * (media_arr / 2);  // Area con media arrotondata
    		printf("Area cerchio (decimale): %.2lf\n", a_c_dec);  
    		printf("Area cerchio (arrotondata): %.2lf\n", a_c_arr);  

    		// Calcolo aree del triangolo equilatero
    		a_t_dec = (sqrt(3) / 4) * media_dec * media_dec;  // Area con media decimale
    		a_t_arr = (sqrt(3) / 4) * media_arr * media_arr;  // Area con media arrotondata
    		printf("Area triangolo equilatero (decimale): %.2lf\n", a_t_dec);  
    		printf("Area triangolo equilatero (arrotondata): %.2lf\n", a_t_arr);  
 		
			// Pulizia buffer input
        	while (getchar() != '\n');  // Rimuove eventuali caratteri residui
		
			// Chiede se ripetere il programma
        	printf("\nVuoi effettuare un nuovo calcolo? (S/N): ");
        	scanf("%c", &scelta);       // Legge la scelta dell'utente
        
    } while (scelta == 's' || scelta == 'S');  // Ripete il programmma se l'utente inserisce 's' o 'S'
   
    return 0;               // Terminazione del programma con successo
}
