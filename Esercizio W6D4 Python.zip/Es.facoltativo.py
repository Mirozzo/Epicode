import math  # Importa il modulo math per usare funzioni matematiche come pi greco e radice quadrata

# Costanti per cambiare il colore del testo
VIOLA = "\033[95m"
VERDE = "\033[92m"
ROSSO = "\033[91m"
RESET = "\033[0m"

# Funzione per l'introduzione e spiegazione del gioco
def introduzione():
    print(VIOLA + "=" * 50)
    print(" BENVENUTO NEL CALCOLATORE DI PERIMETRI E AREE ")
    print("=" * 50)
    # Spiega all'utente cosa fa il programma e quali figure può scegliere
    print("Questo programma ti permette di calcolare perimetro")
    print("e area di alcune figure geometriche: \n- Quadrato \n- Cerchio\n- Rettangolo \n- Triangolo equilatero.")
    print("Inserirai un valore iniziale (lato o raggio) che verrà")
    print("usato per ogni figura. Alla fine potrai ricominciare o uscire.")
    print("-" * 50 + RESET)

# Funzione per l'acquisizione del valore iniziale all'inizio di ogni ciclo
def acquisisci_valore_iniziale():
    while True: # Ciclo continuo finché non viene inserito un valore valido
        try:
            valore = float(input(VERDE + "\nInserisci il valore iniziale (lato/raggio): ")) # Richiede un numero float
            if valore > 0:
                return valore # Ritorna il valore se è maggiore di zero
            else:
                print("Il valore deve essere maggiore di zero. Riprova.") # Avvisa se il numero è negativo o zero
        except ValueError:
            print("Valore non valido. Inserisci un numero.") # Gestisce errori di input non numerico

# Definizione funzione per il calcolo dei perimetri e delle aree delle figure geometriche
def calcola_perimetro_e_area():
    while True: # Ciclo esterno che permette di ricominciare da capo
        
        # Ottiene il valore iniziale tramite la funzione creata e lo associa alla vaiabile "valore"
        valore = acquisisci_valore_iniziale()

        # Dizionario con le figure disponibili che si resetta ad ogni avvio ciclo
        figure_disponibili = {"1": "Quadrato", "2": "Cerchio", "3": "Rettangolo", "4": "Triangolo equilatero"}

        while True: # Ciclo interno per far scegliere le figure
            if not figure_disponibili: # Se tutte le figure sono state calcolate
                scelta_reset = input(ROSSO +"\nHai calcolato tutte le figure disponibili! Vuoi ricominciare? (s/n): ")
                if scelta_reset.lower() == "s": # Se l'utente vuole ricominciare da capo
                    break                       # Esce dal ciclo interno e riparte da capo
                else:
                    print("Uscita dal programma.") # Messaggio di chiusura
                    return  # Termina completamente il programma

            # Mostra le figure disponibili per la scelta dell'utente
            print(VERDE + "\nScegli la figura geometrica per calcolare perimetro e area:")
            for chiave, figura in figure_disponibili.items():
                print(f"{chiave}. {figura}")
            print("5. Esci")  # Opzione per uscire dal programma

            # Acquisizione e scelta valore corrispondente alla figura scelta
            scelta = input("Inserisci il numero corrispondente alla figura: ") 

            # Calcolo per il perimetro e l'area del quadrato
            if scelta == "1" and "1" in figure_disponibili:
                perimetro = valore * 4
                area = valore * valore
                print(VIOLA + f"\nFigura → Quadrato\n- Lato: {valore:.2f}")
                print(f"Perimetro: {perimetro}")
                print(f"Area: {area}" + RESET)
                del figure_disponibili["1"]     # Rimuove la figura già calcolata dal dizionario

            # Calcolo per la circonferenza e l'area del cerchio
            elif scelta == "2" and "2" in figure_disponibili:
                circonferenza = 2 * math.pi * valore
                area = math.pi * valore * valore
                print(VIOLA + f"\nFigura → Cerchio\n- Raggio: {valore:.2f}")
                print(f"Circonferenza: {circonferenza:.2f}")
                print(f"Area: {area:.2f}" + RESET)
                del figure_disponibili["2"]     # Rimuove la figura già calcolata dal dizionario

            # Calcolo per il perimetro e l'area del rettangolo
            elif scelta == "3" and "3" in figure_disponibili:
                altezza = float(input("Inserisci l'altezza del rettangolo (base già impostata): "))  # Richiede altezza del rettangolo
                perimetro = 2 * (valore + altezza)
                area = valore * altezza
                print(VIOLA + f"\nFigura → Rettangolo \n- Base: {valore:.2f} \n- Altezza: {altezza:.2f}")
                print(f"Perimetro: {perimetro}")
                print(f"Area: {area}" + RESET)
                del figure_disponibili["3"]     # Rimuove la figura già calcolata dal dizionario

            # Calcolo per il perimetro e l'area del triangolo equilatero
            elif scelta == "4" and "4" in figure_disponibili:
                perimetro = valore * 3
                area = (valore * valore * math.sqrt(3)) / 4
                print(VIOLA + f"\nFigura → Triangolo equilatero \n- Lato: {valore:.2f}")
                print(f"Perimetro: {perimetro}")
                print(f"Area: {area:.2f}" + RESET)
                del figure_disponibili["4"]     # Rimuove la figura già calcolata dal dizionario

            # Uscita dal programma
            elif scelta == "5":
                print("Uscita dal programma." + RESET)
                return  # Termina completamente il programma

            # Gestione di scelta non valida o già usata
            else:
                print(ROSSO +"Scelta non valida o figura già calcolata. Riprova." + RESET)

# Avvio del programma richiamando le funzioni create
introduzione()  # Mostra l'introduzione
calcola_perimetro_e_area()  # Avvia il calcolo delle figure
