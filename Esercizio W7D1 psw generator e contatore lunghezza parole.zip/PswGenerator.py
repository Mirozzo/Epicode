import random  # Importa il modulo random per generare scelte casuali
import string  # Importa il modulo string per usare insiemi di caratteri predefiniti

VERDE = "\033[92m"
ROSSO = "\033[91m"
AZZURRO = "\033[96m"
BIANCO = "\033[97m"

def introduzione():
    # Funzione che presenta il programma all'utente
    print(AZZURRO +"Benvenuto nel Generatore di Password!")
    print("Questo programma ti permette di creare password sicure con due opzioni:")
    print("- Password Semplice: 8 caratteri (lettere e numeri)")
    print("- Password Complessa: 20 caratteri (lettere, numeri e simboli speciali)")
    print("Potrai generare tutte le password che desideri e uscire quando vuoi.")
    print("------------------------------------------------")

def genera_password():
    # Ciclo infinito per continuare a chiedere finché non si ottiene un input valido o si esce
    while True:
        # Chiede all'utente il tipo di password e normalizza l'input
        scelta = input(VERDE +"Desideri una password Semplice o Complessa? (S/C): ").strip().upper()
        # .strip() rimuove spazi iniziali/finali, .upper() converte in maiuscolo

        # Inizializza variabili vuote che saranno riempite in base alla scelta
        lunghezza = 0  # Lunghezza della password da generare
        caratteri = ""  # Set di caratteri da cui scegliere

        # Controlla se l'utente vuole una password semplice
        if scelta == "S":
            lunghezza = 8  # Imposta la lunghezza a 8 caratteri
            # Usa lettere (maiuscole e minuscole) e numeri
            caratteri = string.ascii_letters + string.digits
        # Controlla se l'utente vuole una password complessa
        elif scelta == "C":
            lunghezza = 20  # Imposta la lunghezza a 20 caratteri
            # Usa lettere, numeri e simboli di punteggiatura
            caratteri = string.ascii_letters + string.digits + string.punctuation
        # Se l'input non è né "S" né "C"
        else:
            # Stampa un messaggio di errore
            print(ROSSO + "Tipo di password non valido. Usa 'S' o 'C'.")
            continue  # Torna all'inizio del ciclo per un nuovo input

        # Genera la password scegliendo casualmente 'lunghezza' caratteri da 'caratteri'
        password = ''.join(random.choices(caratteri, k=lunghezza))
        # random.choices() seleziona casualmente, ''.join() unisce i caratteri in una stringa
        print(f"La password generata è: {BIANCO}{password}{VERDE}")  # Mostra la password generata

        # Secondo ciclo per chiedere se generare un'altra password
        while True:
            # Chiede se l'utente vuole continuare e normalizza l'input
            nuova = input("Vuoi generare un'altra password? (S/N): ").strip().upper()

            # Se l'utente vuole generare un'altra password
            if nuova == "S":
                break  # Esce dal ciclo interno e torna a chiedere S/C
            # Se l'utente vuole terminare
            elif nuova == "N":
                print("Arrivederci!")  # Stampa messaggio di saluto
                return  # Esce dalla funzione, terminando il programma
            # Se l'input non è né "S" né "N"
            else:
                # Stampa un messaggio di errore
                print(ROSSO +"Scelta non valida. Usa 'S' o 'N'." + VERDE)
                continue  # Torna a chiedere S/N

# Esegue prima l'introduzione e poi avvia il generatore
introduzione()  # Chiama la funzione di introduzione
genera_password()  # Avvia la funzione principale