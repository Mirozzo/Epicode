VIOLA = "\033[95m"

def lunghezze_parole(A):
    B = [len(parola) for parola in A]
    return B

while True:
    # Raccolta input dall'utente
    A = []
    print(VIOLA + "\nInserisci le parole (premi Invio senza testo per terminare):")

    while True:
        parola = input("Parola: ")
        if parola == "":
            break
        A.append(parola)

    # Calcolo e stampa del risultato
    if A:  # Controlla se la lista non è vuota
        risultato = lunghezze_parole(A)
        print("Lunghezze delle parole:", risultato)
    else:
        print("Nessuna parola inserita")

    # Chiedo se continuare
    continua = input("\nVuoi inserire un'altra lista? (sì/no): ")
    if continua.lower() != "sì" and continua.lower() != "si":
        print("Programma terminato")
        break