#include <stdio.h>  // Libreria standard per input/output
#include <ctype.h>  // Libreria per funzioni di manipolazione caratteri (toupper)
#include <stdlib.h> // Libreria per funzioni di sistema (system, exit)

// Funzione per introdurre il gioco
void introduzioneGioco() {
    printf("        #### GIOCO DI DOMANDE EPICODE ####\n\n");
    printf("Benvenuti al gioco di domande a risposta multipla\n");
    printf("Rispondi correttamente alle domande e incrementa il tuo punteggio\n\n");
}

// Funzione per mostrare il menu e raccogliere la scelta dell'utente
char menu_scelta() {
    char scelta;
    printf("Scegli un'opzione:\n");
    printf("A. Iniziare una nuova partita\n");
    printf("B. Uscire dal gioco\n");
    printf("Scelta: ");
    scanf(" %c", &scelta); 					// Legge un carattere dall'utente
    return toupper(scelta); 				// Converte la scelta in maiuscolo per gestire input minuscoli
}

// Funzione per raccogliere il nome dell'utente
void inserisciNome() {
    char nomeUtente[50]; 					// Dichiarazione di un array di caratteri per il nome
    printf("\nInserisci il tuo UserName: ");
    scanf(" %s", nomeUtente); 				// Legge il nome dell'utente
    printf("\nBenvenuto %s! Iniziamo a giocare! Buona fortuna!\n", nomeUtente);
}

// Funzione principale del gioco, che gestisce le domande e il punteggio
int gioco() {
    char risposta; 							// Variabile per memorizzare la risposta dell'utente
    int score = 0; 							// Inizializza il punteggio a 0

    // Prima domanda
    printf("\nDomanda 1:\nQual e' il tipo di hacker che opera a scopo benefico?\n");
    printf("1. White hat hacker\n2. Black hat hacker\n3. Gray hat hacker\n");
    printf("Risposta: ");
    scanf(" %c", &risposta);

    if (risposta == '1') { 					// Controlla se la risposta � corretta
        printf("Complimenti! Risposta corretta!\n");
        score++; 							// Incrementa il punteggio
    } else {
        printf("Risposta sbagliata! La risposta giusta e': 1. White hat hacker\n");
    }

    // Seconda domanda
    printf("\nDomanda 2:\nQual e' stato il primo virus informatico?\n");
    printf("1. ILOVEYOU\n2. WannaCry\n3. Creeper\n");
    printf("Risposta: ");
    scanf(" %c", &risposta);

    if (risposta == '3') {
        printf("Complimenti! Risposta corretta!\n");
        score++;
    } else {
        printf("Risposta sbagliata! La risposta giusta e': 3. Creeper\n");
    }

    // Terza domanda
    printf("\nDomanda 3:\nDa quanti livelli e' composto il modello ISO/OSI?\n");
    printf("1. Sette\n2. Quattro\n3. Cinque\n");
    printf("Risposta: ");
    scanf(" %c", &risposta);

    if (risposta == '1') {
        printf("Complimenti! Risposta corretta!\n");
        score++;
    } else {
        printf("Risposta sbagliata! La risposta giusta e': 1. Sette\n");
    }
    
    // Quarta domanda
    printf("\nDomanda 4:\nQuale di questi e' un linguaggio compilato?\n");
    printf("1. JavaScript\n2. C\n3. Python\n");
    printf("Risposta: ");
    scanf(" %c", &risposta);

    if (risposta == '2') {
        printf("Complimenti! Risposta corretta!\n");
        score++;
    } else {
        printf("Risposta sbagliata! La risposta giusta e': 2. C\n");
    }

    printf("\nHai totalizzato un totale di %d punti!\n\n\n", score);
    return score; 							// Ritorna il punteggio ottenuto dal giocatore
}

// Funzione principale del programma
int main() {
    system("color AD"); 					// Cambia i colori della console (Sfondo verde chiaro, Testo magenta)
    char scelta; 							// Variabile per la scelta dell'utente nel menu
    int total_score = 0; 					// Inizializza il punteggio totale

    introduzioneGioco(); 					// Mostra il messaggio introduttivo

    while (1) { 							// Loop infinito fino a quando l'utente sceglie di uscire
        scelta = menu_scelta();				// Mostra il menu e raccoglie l'input dell'utente
        switch (toupper(scelta)) { 			// Controlla la scelta convertita in maiuscolo
            case 'A': 						// Se l'utente sceglie di iniziare una nuova partita
                inserisciNome(); 			// Richiama la funzione per l'inserimento del nome utente
                total_score += gioco(); 	// Funzione per avviare il gioco e somma il punteggio ottenuto
                printf("Il tuo punteggio totale e': %d\n\n", total_score);
                break;
            case 'B': 						// Se l'utente sceglie di uscire
                printf("Il tuo punteggio totale e': %d\n\n", total_score);
                printf("Arrivederci! Premere il tasto invio per uscire...\n");
                getchar(); 					// Cattura l'input dell'utente prima di chiudere
                getchar(); 					// Serve per aspettare un tasto prima di uscire
                return 0; 					// Termina il programma
            default:
                printf("Scelta non valida. Riprova.\n\n");
        }
    }
}

